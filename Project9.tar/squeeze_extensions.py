
from astropy.io import fits

def squeeze_extensions(infile, outfile):

    # Takes in a .fits file with exactly one extension and compresses it down to a single header and data table.  The primary and extension headers are merged into a single header in the saved file.
    # str infile: File path to the multi-extension fits (MEF) file (must have exactly one extension)
    # str outfile: File path for saving the resulting file with a length 1 HDU

    hdu_in = fits.open(infile)  # Read in the file's HDU

    new_header = hdu_in[0].header.copy()  # Copy the primary header from the first card

    for thiskey in hdu_in[1].header.keys():
        new_header[thiskey] = hdu_in[1].header[thiskey]
    # [new_header[thiskey] = hdu_in[1].header[thiskey] for thiskey in hdu_in[1].header.keys()]  # Add entries for all of the headers in the second card

    new_data = hdu_in[1].data  # Grab the data from the second card

    new_hdu = fits.PrimaryHDU(header = new_header, data = new_data)  # All together now!

    new_hdu.writeto(outfile)  # Save the resulting file